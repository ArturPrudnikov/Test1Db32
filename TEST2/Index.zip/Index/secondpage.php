<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="mydiv">
        <h1 style="color:aquamarine">Second page</h1>
        <img src="1Снимок.PNG" alt="">
    </div>
    <div class="mydiv">Hello</div>
    <button onclick="ondivclick"></button>
    <script src=""></script>
</body>
</html>