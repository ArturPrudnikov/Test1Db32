function ondivclick()
{
    document.body.style.backgroundColor = "#AA0000";
}